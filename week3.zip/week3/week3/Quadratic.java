package week3;
/*
 * file : Quadratic.java
 * author : Jacqui Harari
 * created : 2.14.19
 * desc : This program implements quadratic formula
 */
import java.util.Scanner;

public class Quadratic {
public static void main(String[] args) {	
	
	System.out.println("\tWelcome to Quadratic Machine.");
	System.out.println("This program implements quadratic formula.");
	
	Scanner scnr = new Scanner(System.in);
	
	double root1;
	double root2;
	
	double aVar;
	double bVar;
	double cVar;
	double discriminant;
	
	System.out.println("Input value for a: ");
	aVar = scnr.nextDouble();
	System.out.println("Input value for b: ");
	bVar = scnr.nextDouble();
	System.out.println("Input Value for c: ");
	cVar = scnr.nextDouble();
	
	
	discriminant = Math.pow(bVar,  2.0) - (4 * aVar * cVar);
	root1 = (-bVar + Math.sqrt(discriminant)) / (2.0 * aVar);
	root2 = (-bVar - Math.sqrt(discriminant)) / (2.0 * aVar);
	
	System.out.println("Discriminant = " + discriminant);
	System.out.println("Roots = " + root1 + root2);

}
}